export interface LogoDTO {
    LogoCode?: string,
    LogoName?: string,
    LogoType?: string,
    LogoTypeID?: number
}