export interface ItemDTO {
    ItemCode?: string;
    ItemName?: string;
    Price?: number;
    PicturName?: string;
    BitmapPath?: string;
    ItemType?: string;
    LogoCode?: string;
    SecondryFabricID?: string;
    ItmsGrpCod?: number;
}