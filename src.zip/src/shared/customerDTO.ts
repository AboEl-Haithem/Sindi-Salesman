export interface CustomerDTO {
    CardCode?: string;
    CardName?: string;
    Phone1?: number;
    E_Mail?: string;
    Address?: string;
    BirthDate?: string; 
}   