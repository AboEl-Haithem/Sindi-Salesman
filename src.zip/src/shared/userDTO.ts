export interface UserDTO {
    userId?: number;
    userName?: string;
    password?: string;
    isActive?: boolean;
    branchId?: number;
}