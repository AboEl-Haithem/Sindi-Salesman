export interface LoginDto {
    Username?: string,
    Password?: string
}