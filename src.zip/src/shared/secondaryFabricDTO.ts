export interface SecondaryFabricDTO {
    SecondryFabricCode?: string,
    SecondryFabricName?: string,
    CtTypeId?: string
}