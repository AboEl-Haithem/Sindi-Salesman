export interface FabricDTO {
    ItemCode?: string;
    ItemName?: string;
    Price?: number;
    ListName?: string;
    ListNum?: number;
    CtTypeId?: number;
    AvailableQuantity?: number;
}